document.addEventListener("DOMContentLoaded", runFunction);

function runFunction() {
    let checkbox = document.getElementById("flexSwitchCheckDefault");
    let select = document.getelementbyId("ReadingLevel");
    select.addEventListener("onchange", outputSelection);
    checkbox.addEventListener("click", changeBgColor);
    function changeBgColor(){
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
            // Send a message to the current tab
            chrome.tabs.sendMessage(tabs[0].id, {message: "switch_text"});
        })
    }
    function outputSelection() {
        var selectedOption = document.getelementbyId("ReadingLevel").value;
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
            // Send a message to the current tab
            chrome.tabs.sendMessage(tabs[0].id, {message: "change_grade",});
        })
    }
}
